from django.contrib import admin

from order.models import AddFavorite

# Register your models here.
admin.site.register(AddFavorite)